using System;

namespace HS.Common.Memory
{
    public interface ITempSpanGetter<T>
    {
        public Span<T> Get(int length);

        public void Return(Span<T> span, bool clear);
    }
}
