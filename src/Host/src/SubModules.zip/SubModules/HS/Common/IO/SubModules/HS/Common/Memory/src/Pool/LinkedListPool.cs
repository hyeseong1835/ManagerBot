using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;

namespace HS.Common.Memory
{
    public class LinkedListPool<T>
        where T : class
    {
        class Node
        {
            T? value;
            public Node? next;


            public Node(T value, Node? next = null)
            {
                this.value = value;
                this.next = next;
            }


            #region Rent

            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public T RentValue()
            {
                if (value == null)
                    throw new InvalidOperationException("이 노드는 이미 사용 중입니다.");

                T result = value;
                value = null;
                return result;
            }

            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public bool TryRentValue([NotNullWhen(true)] out T? value)
            {
                if (this.value == null)
                {
                    value = null;
                    return false;
                }

                value = this.value;
                this.value = null;
                return true;
            }

            #endregion


            #region Return

            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public void ReturnValue(T value)
            {
                if (this.value != null)
                    throw new InvalidOperationException("이 노드는 이미 값을 가지고 있습니다.");

                this.value = value;
            }

            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public bool TryReturnValue(T value)
            {
                if (this.value != null)
                    return false;

                this.value = value;
                return true;
            }

            #endregion
        }


        Node? head;

        // 대여된 값의 개수
        int rentCount;
        public int RentCount => rentCount;

        // 풀의 크기
        int poolSize;
        public int PoolSize => poolSize;

        // 대여 가능한 값의 개수
        public int AvailableCount => poolSize - rentCount;

        // 값 생성기
        public object? valueFactoryParam;
        public readonly Func<object?, T> valueFactory;


        public LinkedListPool(object? valueFactoryParam, Func<object?, T> valueFactory)
        {
            this.head = null;
            this.poolSize = 0;

            this.valueFactoryParam = valueFactoryParam;
            this.valueFactory = valueFactory ?? throw new ArgumentNullException(nameof(valueFactory), "값 생성기는 null이 될 수 없습니다.");
        }
        public LinkedListPool(Func<object?, T> valueFactory)
        {
            this.head = null;
            this.poolSize = 0;

            this.valueFactoryParam = null;
            this.valueFactory = valueFactory ?? throw new ArgumentNullException(nameof(valueFactory), "값 생성기는 null이 될 수 없습니다.");
        }


        public T Rent()
        {
            Node? next = head;

            T? value;
            while (next != null)
            {
                // 빌릴 수 있다면 값을 빌리고 반환
                if (next.TryRentValue(out value))
                {
                    rentCount++;
                    return value;
                }

                // 다음 노드로 이동
                next = next.next;
            }

            // 새로운 노드를 생성하여 풀에 추가하고 값 대여
            return AddNodeFront().RentValue();
        }

        public void Return([NotNull] T value)
        {
            if (value == null)
                throw new ArgumentNullException(nameof(value), "반환할 값은 null이 될 수 없습니다.");

            Node? next = head;

            while (next != null)
            {
                // 반환할 수 있다면 값을 반환 후 종료
                if (next.TryReturnValue(value))
                {
                    rentCount--;
                    return;
                }

                // 다음 노드로 이동
                next = next.next;
            }

            throw new InvalidOperationException("값을 반환할 공간이 없습니다.");
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        Node AddNodeFront()
        {
            T value = valueFactory.Invoke(valueFactoryParam);
            head = new Node(value, head);
            poolSize++;

            return head;
        }
    }
}
