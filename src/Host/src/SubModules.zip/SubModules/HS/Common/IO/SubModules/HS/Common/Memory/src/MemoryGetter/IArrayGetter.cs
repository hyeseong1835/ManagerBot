namespace HS.Common.Memory
{
    public interface IArrayGetter<T>
    {
        public T[] Get(int minimumLength);
        public void Return(T[] array, bool clear);
    }
}
