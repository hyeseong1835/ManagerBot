using System;

namespace HS.Common.Memory
{
    public class ArrayCreator<T> : IArrayGetter<T>, ITempArrayGetter<T>,
                                    ITempArraySliceGetter<T>
    {
        static Exception CanNotFindReturnArrayException()
        {
            return new InvalidOperationException("반환하려는 배열이 대여한 배열과 일치하지 않습니다.");
        }
        static Exception NoRentArrayException()
        {
            return new InvalidOperationException("대여된 배열이 없습니다.");
        }

        T[] array1;
        T[] array2;

        int rentCount;


        public ArrayCreator()
        {
            this.array1 = Array.Empty<T>();
            this.array2 = Array.Empty<T>();

            this.rentCount = 0;
        }

        public T[] Get(int minimumLength)
        {
            switch (rentCount)
            {
                case 0:
                {
                    if (minimumLength > 0)
                    {
                        array1 = new T[minimumLength];
                    }

                    rentCount = 1;
                    return array1;
                }
                case 1:
                {
                    if (minimumLength > 0)
                    {
                        array2 = new T[minimumLength];
                    }

                    rentCount = 2;
                    return array2;
                }
                default:
                    throw new InvalidOperationException("배열 생성기에서 더 이상 생성할 수 없습니다.");
            }
        }
        ArraySlice<T> ITempArraySliceGetter<T>.Get(int minimumLength) => Get(minimumLength);

        public void Return(T[] array, bool clear = true)
        {
            switch (rentCount)
            {
                case 1:
                {
                    if (array == array1)
                    {
                        if (clear) ClearArray1();

                        rentCount = 0;
                        array1 = Array.Empty<T>();
                        return;
                    }

                    throw CanNotFindReturnArrayException();
                }
                case 2:
                {
                    if (array == array1)
                    {
                        if (clear) ClearArray1();

                        rentCount = 1;
                        array1 = array2;
                        array2 = Array.Empty<T>();
                        return;
                    }

                    if (array == array2)
                    {
                        rentCount = 1;
                        array2 = Array.Empty<T>();
                        return;
                    }

                    throw CanNotFindReturnArrayException();
                }
                default:
                    throw NoRentArrayException();
            }
        }
        void ITempArraySliceGetter<T>.Return(ArraySlice<T> arraySlice, bool clear) => Return(arraySlice.array, clear);

        void ClearArray1()
        {
            Array.Clear(array1, 0, array1.Length);
        }
        void ClearArray2()
        {
            Array.Clear(array2, 0, array2.Length);
        }
    }
}
