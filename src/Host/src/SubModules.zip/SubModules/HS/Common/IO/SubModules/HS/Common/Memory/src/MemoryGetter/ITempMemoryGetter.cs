using System;

namespace HS.Common.Memory
{
    public interface ITempMemoryGetter<T>
    {
        public Memory<T> Get(int length);

        public void Return(Memory<T> memory, bool clear);
    }
}
