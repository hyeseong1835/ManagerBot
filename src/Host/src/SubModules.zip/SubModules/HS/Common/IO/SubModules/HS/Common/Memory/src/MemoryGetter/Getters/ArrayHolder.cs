using System;

namespace HS.Common.Memory
{
    public struct ArrayHolder<T> : ITempArrayGetter<T>, ITempArraySliceGetter<T>, ITempMemoryGetter<T>, ITempSpanGetter<T>
    {
        public static implicit operator ArrayHolder<T>(T[] array) => new ArrayHolder<T>(array);

        T[] array;
        public T[] Array => array;

        public ArrayHolder(T[] array)
        {
            this.array = array;
        }

        public T[] Get()
        {
            return array;
        }

        T[] ITempArrayGetter<T>.Get(int minimumLength) => array;
        ArraySlice<T> ITempArraySliceGetter<T>.Get(int length) => array.Slice(0, length);
        Memory<T> ITempMemoryGetter<T>.Get(int length) => array.AsMemory(0, length);
        Span<T> ITempSpanGetter<T>.Get(int length) => array.AsSpan(0, length);

        void ITempArrayGetter<T>.Return(T[] array, bool clear) { }
        void ITempArraySliceGetter<T>.Return(ArraySlice<T> arraySlice, bool clear) { }
        void ITempMemoryGetter<T>.Return(Memory<T> memory, bool clear) { }
        void ITempSpanGetter<T>.Return(Span<T> span, bool clear) { }
    }
}
