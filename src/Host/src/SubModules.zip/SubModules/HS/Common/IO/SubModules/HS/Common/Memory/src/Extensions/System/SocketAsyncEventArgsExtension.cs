using System.Net.Sockets;

namespace HS.Common.Memory.Extensions.System.Net.Sockets
{
    public static class SocketAsyncEventArgsExtension
    {
        public static void SetBuffer(this SocketAsyncEventArgs args, ArraySlice<byte> buffer)
        {
            args.SetBuffer(buffer.array, buffer.offset, buffer.count);
        }
    }
}
