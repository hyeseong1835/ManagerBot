using System;

namespace HS.Common.Memory
{
    public struct MemoryWriter<TSpanValue>
    {
        Memory<TSpanValue> memory;
        int pos;
        public int Position => pos;

        public MemoryWriter(Memory<TSpanValue> memory, int initialPosition = 0)
        {
            this.memory = memory;
            this.pos = initialPosition;
        }
        public void Write(TSpanValue value)
        {
            if (pos + 1 > memory.Length)
                throw new InvalidOperationException("스판이 가득 찼습니다.");

            memory.Span[pos++] = value;
        }
        public void WriteMany(ReadOnlySpan<TSpanValue> span)
        {
            if (pos + span.Length > this.memory.Length)
                throw new InvalidOperationException("스판이 가득 찼습니다.");

            span.CopyTo(this.memory.Span.Slice(pos, span.Length));
            pos += span.Length;
        }
    }
}
