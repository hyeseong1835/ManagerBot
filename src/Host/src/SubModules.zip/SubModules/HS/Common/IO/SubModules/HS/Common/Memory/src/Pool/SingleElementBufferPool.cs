using System.Runtime.CompilerServices;

namespace HS.Common.Memory
{
    public class SingleElementBufferPool<T>
    {
        public static readonly SingleElementBufferPool<T> Shared = new();

        /// <summary>
        /// 스레드를 점유하지 않을 때 반환이 권장되는 공유 임시 버퍼 풀
        /// </summary>
        public static readonly SingleElementBufferPool<T[]> SharedTemp = new();

        LinkedListPool<T[]> pool = new LinkedListPool<T[]>((param) => new T[1]);


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public T[] Rent()
        {
            return pool.Rent();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void Return(T[] value)
        {
            pool.Return(value);
        }
    }
}
