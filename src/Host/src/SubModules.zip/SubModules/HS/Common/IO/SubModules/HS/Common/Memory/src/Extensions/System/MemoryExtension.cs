using System;
using System.Runtime.InteropServices;

namespace HS.Common.Memory
{
    public static class MemoryExtension
    {
        public static T[] GetArray<T>(this Memory<T> memory)
        {
            if (false == MemoryMarshal.TryGetArray(memory, out ArraySegment<T> segment))
            {
                throw new ArgumentException("잘못된 값입니다. : 메모리에서 배열을 얻을 수 없습니다.", nameof(memory));
            }
            if (segment.Array == null)
                throw new ArgumentException("잘못된 값입니다. : 배열 세그먼트에서 배열을 얻을 수 없습니다.", nameof(memory));

            return segment.Array;
        }
    }
}
