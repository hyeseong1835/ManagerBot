using System;

namespace HS.Common.Memory
{
    public interface IMemoryGetter<T>
    {
        public Memory<T> Get(int length);
        public void Return(Memory<T> memory, bool clear = true);
    }
}
