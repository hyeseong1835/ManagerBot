using System.Buffers;

namespace HS.Common.Memory
{
    public struct TempArrayPooler<T> : ITempArrayGetter<T>
    {
        ArrayPool<T> arrayPool;

        public TempArrayPooler(ArrayPool<T> arrayPool)
        {
            this.arrayPool = arrayPool;
        }

        public T[] Get(int minimumLength)
        {
            return arrayPool.Rent(minimumLength);
        }

        public void Return(T[] array, bool clear)
        {
            arrayPool.Return(array, clear);
        }
    }
}
