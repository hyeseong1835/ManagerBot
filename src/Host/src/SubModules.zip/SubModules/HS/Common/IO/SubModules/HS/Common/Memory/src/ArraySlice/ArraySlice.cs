using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace HS.Common.Memory
{
    public struct ArraySlice<T>
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static implicit operator Memory<T>(ArraySlice<T> slice)
        {
            return slice.Memory;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static implicit operator Span<T>(ArraySlice<T> slice)
        {
            return slice.Span;
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static implicit operator ArraySlice<T>(T[] array)
        {
            return new ArraySlice<T>(array, 0, array.Length);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static explicit operator ArraySlice<T>(Memory<T> segment)
        {
            if (false == MemoryMarshal.TryGetArray(segment, out ArraySegment<T> arraySegment))
            {
                throw new ArgumentException("The provided ReadOnlyMemory<T> does not have an underlying array.");
            }

            return (ArraySlice<T>)arraySegment;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static explicit operator ArraySlice<T>(ArraySegment<T> segment)
        {
            return new ArraySlice<T>(segment.Array!, segment.Offset, segment.Count);
        }


        public T[] array;
        public int offset;
        public int count;

        public ArraySlice(T[] array, int offset, int count)
        {
            this.array = array;
            this.offset = offset;
            this.count = count;
        }

        public ref T this[int index]
        {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get => ref array[index + offset];
        }
        public Memory<T> Memory
        {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get => new Memory<T>(array, offset, count);
        }
        public Span<T> Span
        {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get => new Span<T>(array, offset, count);
        }

        #region AsMemory

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public Memory<T> AsMemory() => new Memory<T>(array, offset, count);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public Memory<T> AsMemory(int start) => new Memory<T>(array, offset + start, count - start - offset);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public Memory<T> AsMemory(int start, int length) => new Memory<T>(array, offset + start, length);

        #endregion

        #region AsSpan

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public Span<T> AsSpan() => new Span<T>(array, offset, count);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public Span<T> AsSpan(int start) => new Span<T>(array, offset + start, count - start - offset);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public Span<T> AsSpan(int start, int length) => new Span<T>(array, offset + start, length);

        #endregion

        #region Slice

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ArraySlice<T> Slice(int start) => new ArraySlice<T>(array, offset + start, count - start);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public Memory<T> SliceAsMemory(int length) => new Memory<T>(array, offset, length);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public Span<T> SliceAsSpan(int length) => new Span<T>(array, offset, length);

        #endregion
    }

    public static partial class ArrayExtension
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ArraySlice<T> Slice<T>(this T[] array, int offset, int count)
        {
            return new ArraySlice<T>(array, offset, count);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ArraySlice<T> Slice<T>(this T[] array, int length)
        {
            return new ArraySlice<T>(array, 0, length);
        }
    }
}
