using System;

namespace HS.Common.Memory
{
    public struct MemoryHolder<T> : ITempMemoryGetter<T>, ITempSpanGetter<T>
    {
        Memory<T> originalMemory;

        public MemoryHolder(Memory<T> memory)
        {
            this.originalMemory = memory;
        }

        public Memory<T> Get(int length)
        {
            if (length > originalMemory.Length)
                throw new InvalidOperationException("저장된 메모리의 길이보다 긴 길이를 요청할 수 없습니다.");

            return originalMemory.Slice(0, length);
        }
        Span<T> ITempSpanGetter<T>.Get(int length)
        {
            if (length > originalMemory.Length)
                throw new InvalidOperationException("저장된 메모리의 길이보다 긴 길이를 요청할 수 없습니다.");

            return originalMemory.Span.Slice(0, length);
        }

        void ITempMemoryGetter<T>.Return(Memory<T> memory, bool clear) { }
        void ITempSpanGetter<T>.Return(Span<T> span, bool clear) { }
    }
}
