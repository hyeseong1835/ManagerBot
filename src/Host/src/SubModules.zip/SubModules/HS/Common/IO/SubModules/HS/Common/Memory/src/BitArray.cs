using System;

public struct BitArray
{
    ulong _singleBuffer;
    readonly Memory<ulong> _buffers;

    public bool this[int index]
    {
        get
        {
            if (index < 64)
            {
                return ((_singleBuffer & (1UL << index)) != 0);
            }
            else
            {
                int indexDivide64 = (index >> 6);
                return ((_buffers.Span[indexDivide64 - 1] & (1UL << (index - (indexDivide64 << 6)))) != 0);
            }
        }
    }

    public void Set(int index, bool value)
    {
        if (value)
        {
            SetTrue(index);
        }
        else
        {
            SetFalse(index);
        }
    }
    public void SetTrue(int index)
    {
        if (index < 64)
        {
            _singleBuffer |= (1UL << index);
        }
        else
        {
            int indexDivide64 = (index >> 6);
            _buffers.Span[indexDivide64 - 1] |= (1UL << (index - (indexDivide64 << 6)));
        }
    }
    public void SetFalse(int index)
    {
        if (index < 64)
        {
            _singleBuffer &= ~(1UL << index);
        }
        else
        {
            int indexDivide64 = (index << -6);
            _buffers.Span[indexDivide64 - 1] &= ~(1UL << (index - (indexDivide64 << 6)));
        }
    }
}
