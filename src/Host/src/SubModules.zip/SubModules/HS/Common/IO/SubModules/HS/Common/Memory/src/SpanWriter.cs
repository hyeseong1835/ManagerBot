using System;

namespace HS.Common.Memory
{
    public ref struct SpanWriter<TSpanValue>
    {
        Span<TSpanValue> span;
        int pos;
        public int Position => pos;

        public SpanWriter(Span<TSpanValue> span, int initialPosition = 0)
        {
            this.span = span;
            this.pos = initialPosition;
        }
        public void Write(TSpanValue value)
        {
            if (pos + 1 > span.Length)
                throw new InvalidOperationException("스판이 가득 찼습니다.");

            span[pos++] = value;
        }
        public void WriteMany(ReadOnlySpan<TSpanValue> span)
        {
            if (pos + span.Length > this.span.Length)
                throw new InvalidOperationException("스판이 가득 찼습니다.");

            span.CopyTo(this.span.Slice(pos, span.Length));
            pos += span.Length;
        }
    }
}
