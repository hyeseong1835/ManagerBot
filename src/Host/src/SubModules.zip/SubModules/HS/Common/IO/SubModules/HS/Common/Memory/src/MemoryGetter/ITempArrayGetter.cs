namespace HS.Common.Memory
{
    public interface ITempArrayGetter<T>
    {
        public T[] Get(int minimumLength);
        public void Return(T[] array, bool clear);
    }
}
