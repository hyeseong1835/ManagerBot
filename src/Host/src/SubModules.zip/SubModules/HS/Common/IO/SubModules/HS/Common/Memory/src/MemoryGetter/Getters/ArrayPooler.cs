using System;
using System.Buffers;
using System.Runtime.InteropServices;

namespace HS.Common.Memory
{
    public struct ArrayPooler<T> : IArrayGetter<T>, ITempArrayGetter<T>, ITempMemoryGetter<T>, ITempArraySliceGetter<T>
    {
        ArrayPool<T> arrayPool;
        T[] array1;
        T[] array2;

        int rentCount;

        public ArrayPooler(ArrayPool<T> arrayPool)
        {
            this.arrayPool = arrayPool;

            this.array1 = Array.Empty<T>();
            this.array2 = Array.Empty<T>();

            this.rentCount = 0;
        }

        public T[] Get(int minimumLength)
        {
            switch (rentCount)
            {
                case 0:
                {
                    if (minimumLength != 0)
                        array1 = arrayPool.Rent(minimumLength);

                    rentCount = 1;
                    return array1 = arrayPool.Rent(minimumLength);
                }
                case 1:
                {
                    if (minimumLength != 0)
                        array2 = arrayPool.Rent(minimumLength);

                    rentCount = 2;
                    return array2;
                }
                default:
                    throw new InvalidOperationException("배열 풀에서 더 이상 대여할 수 없습니다.");
            }
        }
        ArraySlice<T> ITempArraySliceGetter<T>.Get(int minimumLength) => Get(minimumLength).Slice(0, minimumLength);
        Memory<T> ITempMemoryGetter<T>.Get(int minimumLength) => Get(minimumLength).AsMemory(0, minimumLength);

        public void Return(T[] array, bool clear)
        {
            if (clear)
            {
                Array.Clear(array, 0, array.Length);
            }
            switch (rentCount)
            {
                case 1:
                {
                    if (array != array1)
                        throw new InvalidOperationException("반환하려는 배열이 대여한 배열과 일치하지 않습니다.");

                    arrayPool.Return(array1);
                    array1 = Array.Empty<T>();
                    rentCount = 0;
                    return;
                }
                case 2:
                {
                    if (array == array1)
                    {
                        arrayPool.Return(array1);
                        array1 = array2;
                        array2 = Array.Empty<T>();
                        rentCount = 1;
                        return;
                    }

                    if (array == array2)
                    {
                        arrayPool.Return(array2);
                        array2 = Array.Empty<T>();
                        rentCount = 1;
                        return;
                    }

                    throw new InvalidOperationException("반환하려는 배열이 대여한 배열과 일치하지 않습니다.");
                }
                default:
                    throw new InvalidOperationException("반환되지 않은 배열이 없습니다.");
            }
        }
        void ITempArraySliceGetter<T>.Return(ArraySlice<T> slice, bool clear) => Return(slice.array, clear);
        void ITempMemoryGetter<T>.Return(Memory<T> memory, bool clear)
        {
            if (false == MemoryMarshal.TryGetArray(memory, out ArraySegment<T> segment))
            {
                throw new ArgumentException("잘못된 값입니다. : 메모리에서 배열을 얻을 수 없습니다.", nameof(memory));
            }
            if (segment.Array == null)
                throw new ArgumentException("잘못된 값입니다. : 배열 세그먼트에서 배열을 얻을 수 없습니다.", nameof(memory));

            Return(segment.Array, clear);
        }
    }
}
