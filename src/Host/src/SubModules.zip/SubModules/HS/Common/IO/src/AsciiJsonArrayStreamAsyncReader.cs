using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace HS.Common.IO.AsciiJson
{
    public class AsciiJsonArrayStreamAsyncReader
    {
        enum JsonPositionType
        {
            None,
            InString,
            InStringAndEscaping,
        }
        public enum ReadState
        {
            NotCompleted,
            CompletedReadElement,
            CompletedReadAll
        }
        public enum ReaderState : byte
        {
            NotStarted,
            Reading,
            Completed
        }
        struct ReadElementState
        {
            public int writeIndex;
            public JsonPositionType positionType;
            public ReadState readState;
            public int depth;
            public int tryCount;

            public ReadElementState(
                int writeIndex,
                JsonPositionType positionType = JsonPositionType.None,
                ReadState readState = ReadState.NotCompleted,
                int depth = 0, int tryCount = 0)
            {
                this.writeIndex = writeIndex;

                this.positionType = positionType;

                this.readState = readState;

                this.depth = depth;
                this.tryCount = tryCount;
            }
        }

        public struct ReadResult
        {
            public Memory<byte> jsonElementBytes;
            public bool isEndRead;

            public ReadResult(bool isEndRead, Memory<byte> jsonElementBytes)
            {
                this.isEndRead = isEndRead;
                this.jsonElementBytes = jsonElementBytes;
            }
        }

        public struct BufferModifyParameters
        {
            public byte[]? originalBuffer;

            public int readIndex;
            public int readLength;
            public int writeIndex;

            public int tryCount;
            public ReadState readState;

            public object? state;

            public BufferModifyParameters(byte[]? originalBuffer,
                int readIndex, int readLength, int writeIndex,
                int tryCount, ReadState readState, object? state)
            {
                this.originalBuffer = originalBuffer;

                this.readIndex = readIndex;
                this.readLength = readLength;
                this.writeIndex = writeIndex;

                this.tryCount = tryCount;
                this.readState = readState;
                this.state = state;
            }
        }
        public struct BufferModifyData
        {
            public byte[] buffer;
            public int readIndex;

            public BufferModifyData(byte[] buffer, int unProcessedBytesStartIndex)
            {
                this.buffer = buffer;
                this.readIndex = unProcessedBytesStartIndex;
            }
        }

        Stream _stream;

        object? _bufferResizerState;
        Func<BufferModifyParameters, BufferModifyData> _bufferModifier;

        byte[]? _buffer;

        int _readIndex;
        int _readLength;
        ReaderState _state;

        public AsciiJsonArrayStreamAsyncReader(Stream stream,
            object? bufferResizerState = null)
        {
            this._stream = stream;

            this._bufferModifier = static (BufferModifyParameters param) =>
            {
                if (param.originalBuffer == null)
                {
                    return new BufferModifyData(new byte[10], 0);
                }

                if (param.originalBuffer.Length <= param.readIndex)
                {
                    if (param.writeIndex * 2 <= param.originalBuffer.Length)
                    {
                        param.originalBuffer.AsSpan(param.readIndex, param.readLength - param.readIndex)
                                            .CopyTo(param.originalBuffer.AsSpan(param.writeIndex));

                        return new BufferModifyData(param.originalBuffer, param.writeIndex);
                    }
                    else
                    {
                        byte[] newBuffer = new byte[param.writeIndex * 2];

                        param.originalBuffer.AsSpan(0, param.writeIndex).CopyTo(newBuffer);
                        param.originalBuffer.AsSpan(param.readIndex, param.readLength - param.readIndex)
                                            .CopyTo(newBuffer.AsSpan(param.writeIndex));

                        return new BufferModifyData(newBuffer, param.writeIndex);
                    }
                }
                else
                {
                    return new BufferModifyData(param.originalBuffer, param.readIndex);
                }
            };
            this._bufferResizerState = bufferResizerState;

            this._state = ReaderState.NotStarted;
        }
        public AsciiJsonArrayStreamAsyncReader(Stream stream,
            Func<BufferModifyParameters, BufferModifyData> _bufferModifier,
            object? bufferResizerState = null)
        {
            this._stream = stream;

            this._bufferModifier = _bufferModifier;
            this._bufferResizerState = bufferResizerState;

            this._state = ReaderState.NotStarted;
        }

        public ValueTask<ReadResult> ReadAsync()
        {
            // 완료된 상태면 빈 결과 반환
            if (_state == ReaderState.Completed)
            {
                return ValueTask.FromResult(new ReadResult(
                    true,
                    _buffer.AsMemory(0, 0)
                ));
            }

            // 버퍼가 없으면 할당 후 스트림에서 받아들이고 읽기 시작
            if (_buffer == null)
                return ReadStreamAndStartAndReadAsync();

            ReadElementState state = new();

            ReadElement(_buffer, ref state);

            switch (state.readState)
            {
                case ReadState.NotCompleted:
                    return ContinueReadAsync(state);

                case ReadState.CompletedReadElement:
                {
                    // 완료됨
                    ReadResult result = new(
                        false,
                        _buffer.AsMemory(0, state.writeIndex)
                    );

                    return ValueTask.FromResult(result);
                }

                case ReadState.CompletedReadAll:
                {
                    // 완료됨
                    ReadResult result = new(
                        false,
                        _buffer.AsMemory(0, state.writeIndex)
                    );

                    return ValueTask.FromResult(result);
                }

                default:
                    throw new InvalidOperationException("알 수 없는 상태입니다.");
            }

            async ValueTask<ReadResult> ContinueReadAsync(ReadElementState state)
            {
                while (true)
                {
                    // 버퍼 갱신
                    ModifyBuffer(
                        state.writeIndex,
                        state.tryCount,
                        state.readState
                    );

                    await ReadStream(_buffer, state.writeIndex);

                    ReadElement(_buffer, ref state);

                    switch (state.readState)
                    {
                        case ReadState.NotCompleted:
                            continue;

                        case ReadState.CompletedReadElement:
                        {
                            return new ReadResult(
                                false,
                                _buffer.AsMemory(0, state.writeIndex)
                            );
                        }
                        case ReadState.CompletedReadAll:
                        {
                            _state = ReaderState.Completed;

                            return new ReadResult(
                                false,
                                _buffer.AsMemory(0, state.writeIndex)
                            );
                        }

                        default:
                            throw new InvalidOperationException("알 수 없는 상태입니다.");
                    }
                }
            }

            async ValueTask<ReadResult> ReadStreamAndStartAndReadAsync()
            {
                _state = ReaderState.Reading;

                // 버퍼 할당
                ModifyBuffer(
                    0,
                    0,
                    ReadState.NotCompleted
                );

                if (_buffer.Length < 1)
                    throw new InvalidOperationException("버퍼 크기가 너무 작습니다.");

                // 스트림에서 데이터 읽기
                await ReadStream(_buffer, 0);

                if (_readLength == 0)
                    throw new EndOfStreamException("스트림이 비었습니다.");

                // 시작 문자 확인
                int tryCount = 1;
                while (true)
                {
                    byte b = _buffer[_readIndex++];

                    if (b == (byte)'[')
                        break;

                    // 공백이나 제어문자가 아닌 경우 예외
                    if ((byte)'!' < b && b < (byte)'~')
                        throw new JsonException($"잘못된 JSON 배열 시작 문자입니다. : {Encoding.ASCII.GetString(_buffer.AsSpan(0, _readIndex))}");

                    if (_readIndex > _readLength)
                    {
                        // 버퍼 갱신
                        ModifyBuffer(
                            0,
                            tryCount++,
                            ReadState.NotCompleted
                        );

                        await ReadStream(_buffer, 0);
                    }
                }
                ReadElementState state = new();

                while (true)
                {
                    ReadElement(_buffer, ref state);

                    // 버퍼 갱신
                    ModifyBuffer(
                        state.writeIndex,
                        state.tryCount,
                        state.readState
                    );

                    switch (state.readState)
                    {
                        case ReadState.NotCompleted:
                        {
                            _readIndex = state.writeIndex;
                            await ReadStream(_buffer, state.writeIndex);

                            continue;
                        }

                        case ReadState.CompletedReadElement:
                        {
                            return new ReadResult(
                                false,
                                _buffer.AsMemory(0, state.writeIndex)
                            );
                        }
                        case ReadState.CompletedReadAll:
                        {
                            if (state.writeIndex == 0)
                            {
                                _state = ReaderState.Completed;

                                return new ReadResult(
                                    true,
                                    _buffer.AsMemory(0, 0)
                                );
                            }
                            return new ReadResult(
                                false,
                                _buffer.AsMemory(0, state.writeIndex)
                            );
                        }

                        default:
                            throw new InvalidOperationException("알 수 없는 상태입니다.");
                    }
                }
            }
        }

        void ReadElement(byte[] buffer, ref ReadElementState state)
        {
            state.tryCount++;

            while (_readIndex < _readLength)
            {
                byte b = buffer[_readIndex++];

                switch (state.positionType)
                {
                    case JsonPositionType.None:
                    {
                        // 최상위 배열일 경우
                        if (state.depth == 0)
                        {
                            switch (b)
                            {
                                // 문자열 시작
                                case (byte)'"':
                                {
                                    // 문자열 읽기 상태로 변경
                                    state.positionType = JsonPositionType.InString;

                                    // 쓰기
                                    buffer[state.writeIndex++] = b;
                                    break;
                                }

                                // 구분자
                                case (byte)',':
                                {
                                    // 즉시 종료
                                    state.readState = ReadState.CompletedReadElement;
                                    return;
                                }

                                // 배열 시작
                                case (byte)'[':
                                {
                                    // 깊이 증가
                                    state.depth++;

                                    // 쓰기
                                    buffer[state.writeIndex++] = b;
                                    break;
                                }

                                // 배열 종료
                                case (byte)']':
                                {
                                    // 즉시 종료
                                    state.readState = ReadState.CompletedReadAll;
                                    return;
                                }

                                // 객체 시작
                                case (byte)'{':
                                {
                                    // 깊이 증가
                                    state.depth++;

                                    // 쓰기
                                    buffer[state.writeIndex++] = b;
                                    break;
                                }

                                // 객체 종료
                                case (byte)'}':
                                {
                                    throw new JsonException("잘못된 '}' 위치");
                                }

                                // 일반 문자
                                default:
                                {
                                    // 공백이나 제어문자가 아닌 경우만 쓰기
                                    if ((byte)'!' < b && b < (byte)'~')
                                    {
                                        // 쓰기
                                        buffer[state.writeIndex++] = b;
                                    }
                                    break;
                                }
                            }
                        }
                        // 원소 내부 스코프인 경우
                        else
                        {
                            switch (b)
                            {
                                // 문자열 시작
                                case (byte)'"':
                                {
                                    // 문자열 읽기 상태로 변경
                                    state.positionType = JsonPositionType.InString;

                                    // 쓰기
                                    buffer[state.writeIndex++] = b;
                                    break;
                                }

                                // 스코프 시작
                                case (byte)'[':
                                case (byte)'{':
                                {
                                    // 깊이 증가
                                    state.depth++;

                                    // 쓰기
                                    buffer[state.writeIndex++] = b;
                                    break;
                                }

                                // 스코프 종료
                                case (byte)']':
                                case (byte)'}':
                                {
                                    // 깊이 감소
                                    state.depth--;

                                    // 쓰기
                                    buffer[state.writeIndex++] = b;
                                    break;
                                }

                                // 일반 문자
                                default:
                                {
                                    // 공백이나 제어문자가 아닌 경우만 쓰기
                                    if ((byte)'!' < b && b < (byte)'~')
                                    {
                                        // 쓰기
                                        buffer[state.writeIndex++] = b;
                                    }
                                    break;
                                }
                            }
                        }

                        break;
                    }

                    case JsonPositionType.InString:
                    {
                        switch (b)
                        {
                            // 이스케이프 문자
                            case (byte)'\\':
                            {
                                // 이스케이프 상태 추가
                                state.positionType = JsonPositionType.InStringAndEscaping;

                                // 쓰기
                                buffer[state.writeIndex++] = b;
                                break;
                            }

                            // 문자열 종료자
                            case (byte)'"':
                            {
                                // 문자열 읽기 상태 종료
                                state.positionType = JsonPositionType.None;

                                // 쓰기
                                buffer[state.writeIndex++] = b;
                                break;
                            }

                            // 일반 문자
                            default:
                            {
                                // 쓰기
                                buffer[state.writeIndex++] = b;
                                break;
                            }
                        }
                        break;
                    }

                    case JsonPositionType.InStringAndEscaping:
                    {
                        // 문자열 읽기 상태로 복귀
                        state.positionType = JsonPositionType.InString;

                        // 쓰기
                        buffer[state.writeIndex++] = b;
                        break;
                    }

                    default:
                        throw new Exception("알 수 없는 Enum 값입니다.");
                }
            }
        }

        [MemberNotNull(nameof(_buffer))]
        void ModifyBuffer(int writeIndex, int tryCount, ReadState readState)
        {
            BufferModifyData data = _bufferModifier.Invoke(new BufferModifyParameters(
                _buffer,
                _readIndex,
                _readLength,
                writeIndex,
                tryCount,
                readState,
                _bufferResizerState
            ));
            this._buffer = data.buffer;
            this._readLength += (data.readIndex - _readIndex);
            this._readIndex = data.readIndex;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        async ValueTask ReadStream(byte[] buffer, int writeIndex)
        {
            int readedByteCount = await _stream.ReadAsync(
                buffer,
                writeIndex,
                buffer.Length - writeIndex
            );
            _readIndex = writeIndex;
            _readLength = writeIndex + readedByteCount;
        }
    }
}
