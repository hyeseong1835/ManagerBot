namespace HS.Common.Memory
{
    public interface ITempArraySliceGetter<T>
    {
        ArraySlice<T> Get(int minimumLength);
        void Return(ArraySlice<T> arraySlice, bool clear);
    }
}
