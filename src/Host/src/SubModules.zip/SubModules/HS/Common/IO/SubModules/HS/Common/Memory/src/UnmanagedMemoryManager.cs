using System;
using System.Buffers;

namespace HS.Common.Memory
{
    public unsafe class UnmanagedMemoryManager<TValue> : MemoryManager<TValue>
        where TValue : unmanaged
    {
        private readonly TValue* _ptr;
        private readonly int _length;

        public UnmanagedMemoryManager(TValue* ptr, int length)
        {
            _ptr = ptr;
            _length = length;
        }

        public override Span<TValue> GetSpan() => new Span<TValue>(_ptr, _length);
        public override Memory<TValue> Memory => CreateMemory(_length);

        public override MemoryHandle Pin(int elementIndex = 0) => new MemoryHandle(_ptr + elementIndex);
        public override void Unpin() { }

        protected override void Dispose(bool disposing) { }
    }
}
