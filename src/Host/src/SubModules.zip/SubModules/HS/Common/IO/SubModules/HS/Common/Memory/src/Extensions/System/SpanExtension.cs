using System;
using System.Runtime.CompilerServices;

namespace HS.Common.Memory
{
    public static class SpanExtension
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Seperate<T>(this Span<T> span, int index, int count = 1)
        {
            span.Slice(index, span.Length - index - count).CopyTo(span.Slice(index + count));
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Insert<T>(this Span<T> span, T value, int index)
        {
            Seperate(span, index, 1);
            span[index] = value;
        }
        public static Span<T> SliceLast<T>(this Span<T> span, int length)
        {
            if (length < 0)
                throw new ArgumentOutOfRangeException(nameof(length), "length는 음수일 수 없습니다.");

            if (span.Length < length)
                throw new ArgumentOutOfRangeException(nameof(length), "Span의 길이는 length보다 작을 수 없습니다.");

            return span.Slice(span.Length - length, length);
        }
    }
}
