using System;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;

namespace HS.Common.Reflection
{
    public enum ChildTypesLoad : byte
    {
        AllAssembly,
        CallingAssembly,
        DefinedAssembly,
    }
    public struct MethodAttributeInfo<TAttribute>
        where TAttribute : Attribute
    {
        public MethodInfo methodInfo;
        public TAttribute attribute;

        public MethodAttributeInfo(MethodInfo methodInfo, TAttribute attribute)
        {
            this.methodInfo = methodInfo;
            this.attribute = attribute;
        }
    }
    public static class TypeUtility
    {
        public static IEnumerable<Type> GetAllTypes()
        {
            return AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(assembly => assembly.GetTypes());
        }
        public static IEnumerable<MethodAttributeInfo<TAttribute>> GetMethodInfoHasAttribute<TAttribute>(BindingFlags bindingFlags)
            where TAttribute : Attribute
        {
            Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
            for (int assemblyIndex = 0; assemblyIndex < assemblies.Length; assemblyIndex++)
            {
                Assembly assembly = assemblies[assemblyIndex];
                Type[] types = assembly.GetTypes();
                for (int typeIndex = 0; typeIndex < types.Length; typeIndex++)
                {
                    Type type = types[typeIndex];
                    MethodInfo[] methods = type.GetMethods(bindingFlags);
                    for (int methodIndex = 0; methodIndex < methods.Length; methodIndex++)
                    {
                        MethodInfo methodInfo = methods[methodIndex];
                        TAttribute? attribute = methodInfo.GetCustomAttribute<TAttribute>();
                        if (attribute != null)
                        {
                            yield return new MethodAttributeInfo<TAttribute>(methodInfo, attribute);
                        }
                    }
                }
            }
        }

        public static IEnumerable<Type> GetChildTypes<T>(ChildTypesLoad assemblyLoad = ChildTypesLoad.AllAssembly) => GetChildTypes(typeof(T), assemblyLoad);
        public static IEnumerable<Type> GetChildTypes(Type type, ChildTypesLoad assemblyLoad = ChildTypesLoad.AllAssembly)
        {
            switch (assemblyLoad)
            {
                case ChildTypesLoad.AllAssembly:
                {
                    return GetChildTypes(type, TypeUtility.GetAllTypes());
                }
                case ChildTypesLoad.CallingAssembly:
                {
                    return GetChildTypes(type, Assembly.GetCallingAssembly().GetTypes());
                }
                case ChildTypesLoad.DefinedAssembly:
                {
                    return GetChildTypes(type, type.Assembly.GetTypes());
                }
                default: throw new ArgumentOutOfRangeException(nameof(assemblyLoad), assemblyLoad, null);
            }
        }

        public static IEnumerable<Type> GetChildTypes<T>(IEnumerable<Type> types) => GetChildTypes(typeof(T), types);
        public static IEnumerable<Type> GetChildTypes(Type type, IEnumerable<Type> types)
        {
            foreach (Type t in types)
            {
                if (t == null || t.IsTypeDefinition == false || t.IsClass == false || t.IsAbstract)
                    continue;

                if (t.IsSubclassOf(type))
                    yield return t;
            }
        }

        public static IEnumerable<T> CreateChildInstances<T>(ChildTypesLoad assemblyLoad = ChildTypesLoad.AllAssembly)
        {
            IEnumerable<Type> childTypes = GetChildTypes<T>(assemblyLoad);

            foreach (Type childType in childTypes)
            {
                T? instance = (T?)Activator.CreateInstance(childType);

                if (instance == null)
                {
                    Console.WriteLine("Failed to create instance of " + childType.Name);
                    continue;
                }
                yield return instance;
            }
        }
        public static IEnumerable<object> CreateChildInstances(Type type, ChildTypesLoad assemblyLoad = ChildTypesLoad.AllAssembly)
        {
            IEnumerable<Type> childTypes = GetChildTypes(type, assemblyLoad);

            foreach (Type childType in childTypes)
            {
                object? instance = (object?)Activator.CreateInstance(childType);

                if (instance == null)
                {
                    Console.WriteLine("Failed to create instance of " + childType.Name);
                    continue;
                }
                yield return instance;
            }
        }

        public static bool IsTuple(this Type type)
        {
            if (type.IsGenericType == false)
                return false;

            return type.IsSubclassOf(typeof(ITuple));
        }
    }
}
