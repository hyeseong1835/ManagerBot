using System;
using System.Reflection;

namespace HS.Common.Reflection.Extensions.System.Reflection
{
    public static class MethodInfoExtension
    {
        /// <summary>
        /// 이 메서드에서 주어진 유형 'T'의 대리자를 생성합니다.
        /// </summary>
        public static T CreateDelegate<T>(this MethodInfo methodInfo)
            where T : Delegate
            => (T)methodInfo.CreateDelegate(typeof(T));

        /// <summary>
        /// 이 메서드에서 지정된 대상을 사용하여 주어진 유형 'T'의 대리자를 생성합니다.
        /// </summary>
        public static T CreateDelegate<T>(this MethodInfo methodInfo, object? target)
            where T : Delegate
            => (T)methodInfo.CreateDelegate(typeof(T), target);
    }
}
