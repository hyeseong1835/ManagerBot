using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

using HS.Common.Reflection.Extensions.System.Reflection;

namespace HS.Common.Reflection
{
    public interface IAsyncActionBase
    {
        public int ParameterCount { get; }
        public ValueTask InvokeAsync(params object[ ] parameters);
    }

    public abstract class AsyncAction : IAsyncActionBase
    {
        public static AsyncAction Create(MethodInfo info)
        {
            switch (info.ReturnType)
            {
                case Type t when t == typeof(Task):
                {
                    return new TaskAsyncAction(info.CreateDelegate<Func<Task>>());
                }
                case Type t when t == typeof(ValueTask):
                {
                    return new ValueTaskAsyncAction(info.CreateDelegate<Func<ValueTask>>());
                }
                case Type t when t == typeof(void):
                {
                    return new VoidAsyncAction(info.CreateDelegate<Action>());
                }
                default:
                {
                    throw new InvalidOperationException($"'{info.DeclaringType}/{info.Name}'는 Task나 ValueTask, 또는 void를 반환하지않습니다.");
                }
            }
        }


        public int ParameterCount
        {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get => 0;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        ValueTask IAsyncActionBase.InvokeAsync(params object[ ] parameters)
        {
            return InvokeAsync();
        }

        public abstract ValueTask InvokeAsync();
    }
    public class TaskAsyncAction : AsyncAction
    {
        Func<Task> func;

        public TaskAsyncAction(Func<Task> func)
        {
            this.func = func;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public override ValueTask InvokeAsync()
        {
            return new ValueTask(func.Invoke());
        }
    }
    public class ValueTaskAsyncAction : AsyncAction
    {
        Func<ValueTask> func;

        public ValueTaskAsyncAction(Func<ValueTask> func)
        {
            this.func = func;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public override ValueTask InvokeAsync()
        {
            return func.Invoke();
        }
    }
    public class VoidAsyncAction : AsyncAction
    {
        Action action;

        public VoidAsyncAction(Action action, bool block = false)
        {
            this.action = action;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public override ValueTask InvokeAsync()
        {
            action.Invoke();
            return default(ValueTask);
        }
    }

    public abstract class AsyncAction<TParam> : IAsyncActionBase
    {
        public static AsyncAction<TParam> Create(MethodInfo info)
        {
            switch (info.ReturnType)
            {
                case Type t when t == typeof(Task):
                {
                    return new TaskAsyncAction<TParam>(info.CreateDelegate<Func<TParam, Task>>());
                }
                case Type t when t == typeof(ValueTask):
                {
                    return new ValueTaskAsyncAction<TParam>(info.CreateDelegate<Func<TParam, ValueTask>>());
                }
                case Type t when t == typeof(void):
                {
                    return new VoidAsyncAction<TParam>(info.CreateDelegate<Action<TParam>>());
                }
                default:
                {
                    throw new InvalidOperationException($"'{info.DeclaringType}/{info.Name}'는 Task나 ValueTask, 또는 void를 반환하지않습니다.");
                }
            }
        }


        public int ParameterCount
        {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get => 1;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        ValueTask IAsyncActionBase.InvokeAsync(params object[ ] parameters)
        {
            return InvokeAsync((TParam)parameters[0]);
        }

        public abstract ValueTask InvokeAsync(TParam param);
    }
    public class TaskAsyncAction<TParam> : AsyncAction<TParam>
    {
        Func<TParam, Task> func;

        public TaskAsyncAction(Func<TParam, Task> func)
        {
            this.func = func;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public override ValueTask InvokeAsync(TParam param)
        {
            return new ValueTask(func.Invoke(param));
        }
    }
    public class ValueTaskAsyncAction<TParam> : AsyncAction<TParam>
    {
        Func<TParam, ValueTask> func;

        public ValueTaskAsyncAction(Func<TParam, ValueTask> func)
        {
            this.func = func;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public override ValueTask InvokeAsync(TParam param)
        {
            return func.Invoke(param);
        }
    }
    public class VoidAsyncAction<TParam> : AsyncAction<TParam>
    {
        Action<TParam> action;

        public VoidAsyncAction(Action<TParam> action, bool block = false)
        {
            this.action = action;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public override ValueTask InvokeAsync(TParam param)
        {
            action.Invoke(param);
            return default;
        }
    }
}
