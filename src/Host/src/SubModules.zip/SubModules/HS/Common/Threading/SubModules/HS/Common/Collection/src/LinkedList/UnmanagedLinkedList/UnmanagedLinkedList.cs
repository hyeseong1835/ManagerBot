using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace HS.Common.Collection.Unmanaged;

/// <summary>
/// 관리되지 않는 메모리에서 싱글 링크드 리스트를 구현합니다. <br/>
/// <br/>
/// 더 이상 사용하지 않을 때 Dispose()를 호출해야합니다.
/// </summary>
/// <typeparam name="TNode"></typeparam>
unsafe public struct UnmanagedLinkedList<TNode>
    : IUnmanagedLinkedList<TNode>,
      IEnumerable<TNode>,
      IPtrEnumerable<TNode>
    where TNode : unmanaged, IUnmanagedLinkedListNode<TNode>
{
    #region Static

    static TNode* AllocNodePtr()
    {
        TNode* newNodePtr = (TNode*)Marshal.AllocHGlobal(sizeof(TNode));

        return newNodePtr;
    }
    static TNode* AllocNodePtr(TNode node)
    {
        TNode* newNodePtr = (TNode*)Marshal.AllocHGlobal(sizeof(TNode));
        *newNodePtr = node;

        return newNodePtr;
    }

    #endregion


    #region Instance

    #region Field & Property

    TNode* headNodePtr;
    public TNode* HeadNodePtr => headNodePtr;

    TNode* tailNodePtr;
    public TNode* TailNodePtr => tailNodePtr;

    int count;
    public int Count
    {
        get => count;
        set => count = value;
    }

    public bool IsEmpty => (count == 0);

    #endregion


    #region Constructor

    public UnmanagedLinkedList()
    {
        this.headNodePtr = null;
        this.tailNodePtr = null;
        this.count = 0;
    }

    #endregion

    #region Method

    public void AddFirst(TNode node)
    {
        // 노드 연결 (new -> head)
        node.NextNodePtr = headNodePtr;

        // 노드 메모리 할당
        TNode* newNodePtr = AllocNodePtr(node);

        // 머리 노드 재설정
        headNodePtr = newNodePtr;

        // 1개만 있으면 꼬리 노드 재설정
        if (count == 1)
        {
            tailNodePtr = newNodePtr;
        }

        // 개수 업데이트
        count++;
    }

    public void AddLast(TNode node)
    {
        // 노드 생성
        TNode* newNodePtr = AllocNodePtr(node);

        // 리스트가 비어 있으면 -> head, tail 노드에 할당
        if (count == 0)
        {
            headNodePtr = newNodePtr;
            tailNodePtr = newNodePtr;
        }
        else
        {
            // 노드 연결 (tail -> new)
            tailNodePtr->NextNodePtr = newNodePtr;

            // 꼬리 노드 재설정
            tailNodePtr = newNodePtr;

        }

        // 개수 업데이트
        count++;
    }

    public void InsertNextTo(TNode* prevNodePtr, TNode newNode)
    {
        if (prevNodePtr == null)
            throw new InvalidOperationException("이전 노드 포인터가 null입니다.");

        // 노드 생성
        TNode* newNodePtr = AllocNodePtr(newNode);

        // 노드 연결 (prev -> new)
        prevNodePtr->NextNodePtr = newNodePtr;

        // 개수 업데이트
        count++;
    }

    public void RemoveFirst()
    {
        if (headNodePtr == null)
            throw new InvalidOperationException("리스트가 비어 있습니다.");

        TNode* secondNodePtr = headNodePtr->NextNodePtr;

        Marshal.FreeHGlobal((IntPtr)headNodePtr);

        headNodePtr = secondNodePtr;

        count--;
    }

    public void Clear()
    {
        switch (count)
        {
            case 0: break;

            case 1:
            {
                Marshal.FreeHGlobal((IntPtr)headNodePtr);
                break;
            }

            case 2:
            {
                Marshal.FreeHGlobal((IntPtr)headNodePtr);
                Marshal.FreeHGlobal((IntPtr)tailNodePtr);
                break;
            }

            default:
            {
                UnmanagedLinkedListNodeEnumerator<TNode> childListEnumerator = new(headNodePtr);

                childListEnumerator.MoveNext();
                TNode* curNodePtr = childListEnumerator.CurrentNodePtr;
                TNode* prevNodePtr;

                while (childListEnumerator.MoveNext())
                {
                    prevNodePtr = curNodePtr;

                    curNodePtr = childListEnumerator.CurrentNodePtr;

                    Marshal.FreeHGlobal((IntPtr)prevNodePtr);
                }

                Marshal.FreeHGlobal((IntPtr)curNodePtr);
                break;
            }
        }

        headNodePtr = null;
        tailNodePtr = null;
        count = 0;
    }

    public void Link<TList>(TList list)
        where TList : IUnmanagedLinkedList<TNode>
    {
        if (tailNodePtr == null)
        {
            headNodePtr = list.HeadNodePtr;
            tailNodePtr = list.TailNodePtr;
        }
        else
        {
            tailNodePtr->NextNodePtr = list.HeadNodePtr;
            tailNodePtr = list.TailNodePtr;
        }

        count += list.Count;
    }

    public void Dispose()
    {
        Clear();
    }


    public UnmanagedLinkedListNodeEnumerator<TNode> GetEnumerator()
        => new UnmanagedLinkedListNodeEnumerator<TNode>(headNodePtr);
    IEnumerator<TNode> IEnumerable<TNode>.GetEnumerator()
        => new UnmanagedLinkedListNodeEnumerator<TNode>(headNodePtr);

    IEnumerator IEnumerable.GetEnumerator()
        => new UnmanagedLinkedListNodeEnumerator<TNode>(headNodePtr);

    public UnmanagedLinkedListNodeEnumerator<TNode> GetPtrEnumerator()
        => GetEnumerator();

    IPtrEnumerator<TNode> IPtrEnumerable<TNode>.GetPtrEnumerator()
        => GetEnumerator();

    #endregion

    #endregion
}
