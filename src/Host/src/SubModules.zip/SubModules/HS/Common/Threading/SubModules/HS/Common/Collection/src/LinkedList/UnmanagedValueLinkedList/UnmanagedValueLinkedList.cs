using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace HS.Common.Collection.Unmanaged;

/// <summary>
/// 관리되지 않는 메모리에서 싱글 링크드 리스트를 구현합니다. <br/>
/// <br/>
/// 더 이상 사용하지 않을 때 Dispose()를 호출해야합니다.
/// </summary>
/// <typeparam name="TValue"></typeparam>
[StructLayout(LayoutKind.Sequential)]
unsafe public struct UnmanagedValueLinkedList<TValue>
    : IUnmanagedValueLinkedList<TValue, UnmanagedValueLinkedListNode<TValue>>,
      IEnumerable<TValue>,
      IPtrEnumerable<UnmanagedValueLinkedListNode<TValue>>
    where TValue : unmanaged
{
    #region Instance

    #region Field & Property

    UnmanagedLinkedList<UnmanagedValueLinkedListNode<TValue>> rawList;

    public UnmanagedValueLinkedListNode<TValue>* HeadNodePtr => rawList.HeadNodePtr;
    public TValue HeadValue => (HeadNodePtr->Value);
    public TValue* HeadValuePtr => (TValue*)((nint)HeadNodePtr + UnmanagedValueLinkedListNode<TValue>.valuePtrOffset);
    public ref TValue HeadValueRef => ref *HeadValuePtr;

    public UnmanagedValueLinkedListNode<TValue>* TailNodePtr => rawList.TailNodePtr;
    public TValue TailValue => TailNodePtr->Value;
    public TValue* TailValuePtr => (TValue*)((nint)TailNodePtr + UnmanagedValueLinkedListNode<TValue>.valuePtrOffset);
    public ref TValue TailValueRef => ref *TailValuePtr;

    public int Count
    {
        get => rawList.Count;
        set => rawList.Count = value;
    }

    public bool IsEmpty => (Count == 0);

    #endregion


    #region Constructor

    public UnmanagedValueLinkedList()
    {
    }

    #endregion

    #region Method

    public void AddFirst(UnmanagedValueLinkedListNode<TValue> node)
        => rawList.AddFirst(node);
    public void AddFirst(TValue value)
        => AddFirst(new UnmanagedValueLinkedListNode<TValue>(value));

    public void AddLast(UnmanagedValueLinkedListNode<TValue> node)
        => rawList.AddLast(node);
    public void AddLast(TValue value)
        => AddLast(new UnmanagedValueLinkedListNode<TValue>(value));

    public void InsertNextTo(UnmanagedValueLinkedListNode<TValue>* prevNodePtr, UnmanagedValueLinkedListNode<TValue> newNode)
        => rawList.InsertNextTo(prevNodePtr, newNode);
    public void InsertNextTo(UnmanagedValueLinkedListNode<TValue>* prevNodePtr, TValue value)
        => InsertNextTo(prevNodePtr, new UnmanagedValueLinkedListNode<TValue>(value));

    public void RemoveFirst()
        => rawList.RemoveFirst();

    public void Clear()
        => rawList.Clear();

    public void Link<TList>(TList list)
        where TList : IUnmanagedLinkedList<UnmanagedValueLinkedListNode<TValue>>
        => rawList.Link(list);

    public void Dispose()
        => rawList.Dispose();

    public UnmanagedLinkedListNodeEnumerator<UnmanagedValueLinkedListNode<TValue>> GetNodeEnumerator()
        => rawList.GetEnumerator();
    IPtrEnumerator<UnmanagedValueLinkedListNode<TValue>> IPtrEnumerable<UnmanagedValueLinkedListNode<TValue>>.GetPtrEnumerator()
        => GetNodeEnumerator();

    public UnmanagedValueLinkedListValueEnumerator<TValue> GetValueEnumerator()
        => new UnmanagedValueLinkedListValueEnumerator<TValue>(this);
    IEnumerator<TValue> IEnumerable<TValue>.GetEnumerator()
        => GetValueEnumerator();
    IEnumerator IEnumerable.GetEnumerator()
        => GetValueEnumerator();

    #endregion

    #endregion
}

/// <summary>
/// 관리되지 않는 메모리에서 싱글 링크드 리스트를 구현합니다. <br/>
/// <br/>
/// 더 이상 사용하지 않을 때 Dispose()를 호출해야합니다.
/// </summary>
/// <typeparam name="TValue"></typeparam>
/// <typeparam name="TNode"></typeparam>
[StructLayout(LayoutKind.Sequential)]
unsafe public struct UnmanagedValueLinkedList<TValue, TNode>
    : IUnmanagedValueLinkedList<TValue, TNode>,
      IEnumerable<TValue>,
      IPtrEnumerable<TNode>
    where TValue : unmanaged
    where TNode : unmanaged, IUnmanagedValueLinkedListNode<TValue, TNode>
{
    #region Static

    static TNode CreateNode()
        => new TNode();
    static TNode CreateNode(TValue value)
    {
        TNode newNode = CreateNode();
        newNode.Value = value;

        return newNode;
    }
    static TNode CreateNode(TValue value, TNode* nextNodePtr)
    {
        TNode newNode = CreateNode();
        newNode.Value = value;
        newNode.NextNodePtr = nextNodePtr;

        return newNode;
    }

    #endregion


    #region Instance

    #region Field & Property

    UnmanagedLinkedList<TNode> rawList;

    public TNode* HeadNodePtr => rawList.HeadNodePtr;
    public TValue HeadValue => (HeadNodePtr->Value);

    public TNode* TailNodePtr => rawList.TailNodePtr;
    public TValue TailValue => TailNodePtr->Value;

    public int Count {
        get => rawList.Count;
        set => rawList.Count = value;
    }

    public bool IsEmpty => (Count == 0);

    #endregion


    #region Constructor

    public UnmanagedValueLinkedList()
    {

    }

    #endregion

    #region Method

    public void AddFirst(TNode node)
        => rawList.AddFirst(node);
    public void AddFirst(TValue value)
        => AddFirst(CreateNode(value));

    public void AddLast(TNode node)
        => rawList.AddLast(node);
    public void AddLast(TValue value)
        => AddLast(CreateNode(value));

    public void InsertNextTo(TNode* prevNodePtr, TNode newNode)
        => rawList.InsertNextTo(prevNodePtr, newNode);
    public void InsertNextTo(TNode* prevNodePtr, TValue value)
        => InsertNextTo(prevNodePtr, CreateNode(value));

    public void RemoveFirst()
        => rawList.RemoveFirst();

    public void Link<TList>(TList list)
        where TList : IUnmanagedLinkedList<TNode>
        => rawList.Link(list);

    public void Dispose()
        => rawList.Dispose();

    public UnmanagedLinkedListNodeEnumerator<TNode> GetNodeEnumerator()
        => rawList.GetEnumerator();
    IPtrEnumerator<TNode> IPtrEnumerable<TNode>.GetPtrEnumerator()
        => GetNodeEnumerator();

    public UnmanagedValueLinkedListValueEnumerator<TValue, TNode> GetValueEnumerator()
        => new UnmanagedValueLinkedListValueEnumerator<TValue, TNode>(this);
    IEnumerator<TValue> IEnumerable<TValue>.GetEnumerator()
        => GetValueEnumerator();
    IEnumerator IEnumerable.GetEnumerator()
        => GetValueEnumerator();

    #endregion

    #endregion
}
