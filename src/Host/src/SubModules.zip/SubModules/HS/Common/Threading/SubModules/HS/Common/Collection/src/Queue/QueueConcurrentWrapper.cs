using System.Diagnostics.CodeAnalysis;

namespace HS.Common.Collection
{
    public class QueueConcurrentWrapper<T, TQueue> : IConcurrentQueue<T>, IQueue<T>
        where TQueue : IQueue<T>
    {
        readonly TQueue _innerQueue;
        readonly object _lock = new object();

        public QueueConcurrentWrapper(TQueue innerQueue)
        {
            _innerQueue = innerQueue;
        }

        public int Count
        {
            get
            {
                lock (_lock)
                {
                    return _innerQueue.Count;
                }
            }
        }

        public void Enqueue(T item)
        {
            lock (_lock)
            {
                _innerQueue.Enqueue(item);
            }
        }

        public bool TryDequeue([NotNullWhen(true)] out T? item)
        {
            lock (_lock)
            {
                return _innerQueue.TryDequeue(out item);
            }
        }
    }
}
