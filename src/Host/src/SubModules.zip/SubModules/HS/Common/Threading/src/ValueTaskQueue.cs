using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

using HS.Common.Collection;

namespace HS.Common.Threading
{
    public class ValueTaskQueue
    {
        IQueue<Func<ValueTask>> _queue;

        Func<ValueTask>? _starter;
        object _lock = new object();
        bool _isDrainQueue = false;

        public ValueTaskQueue(IQueue<Func<ValueTask>> queue)
        {
            if (queue == null)
                throw new ArgumentNullException(nameof(queue));
            if (queue.Count != 0)
                throw new ArgumentException("Queue must be empty", nameof(queue));

            this._queue = queue;

            this._starter = null;
        }

        public void Enqueue(Func<ValueTask> func)
        {
            // 실행 중이면 넣고 그냥 감
            if (_isDrainQueue)
            {
                _queue.Enqueue(func);
                return;
            }

            // 실행 중이지 않으면 실행 중으로 변경
            _isDrainQueue = true;

            // 임시 변수 등록
            _starter = starter;

            ThreadPool.QueueUserWorkItem(
                static async s => s.DrainQueue(s._starter!),
                this
            );

            _starter = null;
        }

        async void DrainQueueAsync(Func<ValueTask> starter)
        {
            ValueTaskQueue state = (ValueTaskQueue)s!;

            // 불쏘시개 즉시 실행
            await starter.Invoke().ConfigureAwait(false);

            while (true)
            {
                // 즉시 큐에서 뽑을 수 있음
                if (state._queue.TryDequeue(out Func<ValueTask>? nextFunc))
                {
                    await nextFunc.Invoke().ConfigureAwait(false);

                    continue;
                }
                // 즉시 큐에서 뽑을 수 없는 상황
                else
                {
                    // 진짜 없음 or 들어오는 중임
                    // 들어오는 중 체크 + 락으로 대기
                }
            }
        }
    }
}
/*
using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

using HS.Common.Collection;

namespace HS.Common.Threading
{
    public class ValueTaskQueue
    {
        IQueue<Func<ValueTask>> _queue;

        Func<ValueTask>? _starter;

        bool _isDrainQueue;

        public ValueTaskQueue(IQueue<Func<ValueTask>> queue)
        {
            if (queue == null)
                throw new ArgumentNullException(nameof(queue));
            if (queue.Count != 0)
                throw new ArgumentException("Queue must be empty", nameof(queue));

            this._queue = queue;

            this._starter = null;
        }

        public void Enqueue(Func<ValueTask> func)
        {
            // 독립 실행 보장
            if (false == Interlocked.CompareExchange(ref _isDrainQueue, true, false))
            {
                // 임시 변수 등록
                _starter = starter;

                ThreadPool.QueueUserWorkItem(
                    static async s => s.DrainQueue(s._starter!),
                    this
                );

                // 임시 변수 해제
                _starter = null;
            }
            // 누가 실행 중임 => 처리 해줄 거라 믿고 그냥 넣기
            else
            {
                _queue.Enqueue(func);
            }
        }

        async void DrainQueue(Func<ValueTask> starter)
        {
            ValueTaskQueue state = (ValueTaskQueue)s!;
            Func<ValueTask> starter = state._starter!;

            // 불쏘시개 즉시 실행
            await starter.Invoke().ConfigureAwait(false);

            while (true)
            {
                // 다음 작업 꺼내기
                Func<ValueTask>? nextFunc;
                if (state._queue.TryDequeue(out nextFunc))
                {
                    // 성공했으면 다음 작업 실행
                    await nextFunc!.Invoke().ConfigureAwait(false);
                }
                // 큐에 원소가 들어오는 중일 수도 있음
                else
                {
                    // ?
                }
            }
        }
    }
}

*/
