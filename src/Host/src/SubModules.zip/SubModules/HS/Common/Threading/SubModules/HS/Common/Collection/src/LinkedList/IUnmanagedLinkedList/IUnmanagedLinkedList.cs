namespace HS.Common.Collection.Unmanaged;

/// <summary>
/// 관리되지 않는 메모리에서 싱글 링크드 리스트를 구현합니다. <br/>
/// <br/>
/// 더 이상 사용하지 않을 때 Dispose()를 호출해야합니다.
/// </summary>
/// <typeparam name="TNode"></typeparam>
unsafe public interface IUnmanagedLinkedList<TNode>
    where TNode : unmanaged, IUnmanagedLinkedListNode<TNode>
{
    TNode* HeadNodePtr { get; }

    TNode* TailNodePtr { get; }

    int Count { get; protected set; }
    
    bool IsEmpty { get; }
}