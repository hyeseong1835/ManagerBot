using System.Diagnostics.CodeAnalysis;

namespace HS.Common.Collection
{
    public interface IQueue<T>
    {
        int Count { get; }

        void Enqueue(T item);
        bool TryDequeue([NotNullWhen(true)] out T? item);
    }
}
