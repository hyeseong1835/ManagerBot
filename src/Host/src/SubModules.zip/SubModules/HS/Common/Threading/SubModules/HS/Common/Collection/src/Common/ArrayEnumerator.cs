using System;
using System.Collections;
using System.Collections.Generic;

namespace HS.Common.Collection;

public struct ArrayEnumerator<T> : IEnumerator<T>
{
    readonly T[] array;
    int index;

    public T Current => array[index];

    object? IEnumerator.Current => Current;


    public ArrayEnumerator(T[] array, int startIndex = -1)
    {
        this.array = array ?? throw new ArgumentNullException(nameof(array));
        this.index = startIndex;
    }


    public bool MoveNext()
    {
        if (index + 1 >= array.Length)
            return false;

        index++;
        return true;
    }

    public void Reset()
    {
        index = -1;
    }

    public void Dispose()
        => throw new NotImplementedException();
}
