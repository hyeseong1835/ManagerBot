using System;
using System.Collections;
using System.Collections.Generic;

namespace HS.Common.Collection;

public struct ReadOnlyMemoryEnumerator<T> : IEnumerator<T>
{
    readonly ReadOnlyMemory<T> memory;
    int index;

    public T Current => memory.Span[index];

    T IEnumerator<T>.Current => throw new NotImplementedException();
    object? IEnumerator.Current => Current;

    public ReadOnlyMemoryEnumerator(ReadOnlyMemory<T> memory, int startIndex = 0)
    {
        this.memory = memory;
        this.index = startIndex - 1;
    }


    public bool MoveNext()
    {
        if (index + 1 >= memory.Length)
            return false;

        index++;
        return true;
    }

    public void Reset()
        => throw new NotSupportedException();

    public void Dispose()
        => throw new NotImplementedException();
}
