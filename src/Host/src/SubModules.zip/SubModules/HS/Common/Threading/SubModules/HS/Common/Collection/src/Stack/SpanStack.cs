using System;

namespace HS.Common.Collection;

public ref struct SpanStack<T>
{
    readonly Span<T> buffer;

    int count;
    public int Count => count;
    public bool IsEmpty => count == 0;


    public SpanStack(Span<T> buffer)
    {
        this.buffer = buffer;
        count = 0;
    }


    public void Push(T item)
    {
        if (count >= buffer.Length)
            throw new InvalidOperationException("버퍼가 가득찼습니다.");

        buffer[count++] = item;
    }

    public T Pop()
    {
        if (IsEmpty)
            throw new InvalidOperationException("원소가 없습니다.");

        return buffer[--count];
    }

    public T Peek()
    {
        if (IsEmpty)
            throw new InvalidOperationException("원소가 없습니다.");

        return buffer[count - 1];
    }

    public ref T PeekRef()
    {
        if (IsEmpty)
            throw new InvalidOperationException("원소가 없습니다.");

        return ref buffer[count - 1];
    }
}
