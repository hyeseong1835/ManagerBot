using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;

using HS.Common.Memory;

namespace HS.Common.Collection;

/// <summary>
/// 버퍼를 사용하여 정렬된 키-값 쌍을 저장하는 사전입니다. <br/>
/// 이진 탐색을 이용하여 탐색합니다.
/// </summary>
/// <typeparam name="TKey"></typeparam>
/// <typeparam name="TValue"></typeparam>
public class SortedListDictionary<TKey, TValue>
    where TKey : IComparable<TKey>
{
    public struct KeyValuePair
    {
        public readonly TKey key;
        public TValue value;

        public KeyValuePair(TKey key, TValue value)
        {
            this.key = key;
            this.value = value;
        }
    }


    void CheckListEmpty()
    {
        if (Count == 0)
            throw new InvalidOperationException("리스트가 비어 있습니다.");
    }
    static Exception KeyNotFoundException(TKey key)
    {
        return new KeyNotFoundException($"키 ({key})가 존재하지 않습니다.");
    }
    static Exception AlreadyExistsKeyException(TKey key)
    {
        return new ArgumentException($"키 ({key})는 이미 존재하는 키입니다.");
    }

    Memory<KeyValuePair> memory;
    IMemoryGetter<KeyValuePair> memoryGetter;

    public int Count => memory.Length;

    public ref TValue this[TKey key]
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        get => ref GetValueRef(key);
    }

    SortedListDictionary(IMemoryGetter<KeyValuePair> memoryGetter)
    {
        this.memory = memoryGetter.Get(0);
        this.memoryGetter = memoryGetter;
    }

    public void Add(TKey key, TValue value)
    {
        bool isSame;
        int lessKeyPairIndex = GetHasSameOrLessKeyPairIndex(key, out isSame);

        if (isSame)
            throw AlreadyExistsKeyException(key);

        Insert(lessKeyPairIndex + 1, key, value);
    }
    public void AddOrUpdate(TKey key, TValue value)
    {
        bool isSame;
        int lessKeyPairIndex = GetHasSameOrLessKeyPairIndex(key, out isSame);

        if (isSame)
        {
            memory.Span[lessKeyPairIndex] = new KeyValuePair(key, value);
            return;
        }
        else
        {
            Insert(lessKeyPairIndex + 1, key, value);
        }
    }

    /// <summary>
    /// 지정된 키의 아이템을 제거하고 그 뒤의 아이템을 당깁니다. <br/>
    /// 마지막 아이템은 복제됩니다. 후에 참조가 제거되지 않을 수 있으므로 메모리 누수 위험이 있는 경우 RemoveCompletely(TKey)를 사용하세요
    /// </summary>
    /// <param name="key"></param>
    /// <exception cref="InvalidOperationException"></exception>
    /// <exception cref="KeyNotFoundException"></exception>
    public void Remove(TKey key)
    {
        CheckListEmpty();

        int sameOrLessKeyPairIndex = GetHasSameOrLessKeyPairIndex(key, out bool isSame);
        if (isSame)
        {
            Pull(sameOrLessKeyPairIndex);
        }
        else
        {
            throw KeyNotFoundException(key);
        }
    }

    /// <summary>
    /// 지정된 키의 아이템을 제거하고 그 뒤의 아이템을 당깁니다. <br/>
    /// 마지막 아이템은 초기화됩니다. 메모리 누수 위험이 없는 경우 Remove(TKey)가 성능상 더 좋습니다.
    /// </summary>
    /// <param name="key"></param>
    /// <exception cref="InvalidOperationException"></exception>
    /// <exception cref="KeyNotFoundException"></exception>
    public void RemoveCompletely(TKey key)
    {
        CheckListEmpty();

        int sameOrLessKeyPairIndex = GetHasSameOrLessKeyPairIndex(key, out bool isSame);
        if (isSame)
        {
            PullCompletely(sameOrLessKeyPairIndex);
        }
        else
        {
            throw new KeyNotFoundException($"키 ({key})가 존재하지 않습니다.");
        }
    }

    public ref TValue GetValueRef(TKey key)
    {
        int sameOrLessKeyPairIndex = GetHasSameOrLessKeyPairIndex(key, out bool isSame);
        if (isSame)
        {
            return ref memory.Span[sameOrLessKeyPairIndex].value;
        }
        else
        {
            throw KeyNotFoundException(key);
        }
    }

    public TValue GetValue(TKey key)
        => GetValueRef(key);

    public void SetValue(TKey key, TValue value)
        => GetValueRef(key) = value;

    public bool TryGetValue(TKey key, [MaybeNullWhen(false)] out TValue value)
    {
        int sameOrLessKeyPairIndex = GetHasSameOrLessKeyPairIndex(key, out bool isSame);
        if (isSame)
        {
            value = memory.Span[sameOrLessKeyPairIndex].value;
            return true;
        }
        else
        {
            value = default;
            return false;
        }
    }

    public bool Contains(TKey key)
    {
        GetHasSameOrLessKeyPairIndex(key, out bool isSame);
        return isSame;
    }

    /// <summary>
    /// 개수를 0으로 설정합니다. <br/>
    /// 참조가 제거되지 않으므로 메모리 누수 위험이 있습니다. 내부 배열을 모두 초기화하려면 ClearCompletely()를 사용하세요.
    /// </summary>
    public void Clear()
    {
        memoryGetter.Return(memory);
        memory = memoryGetter.Get(0);
    }

    /// <summary>
    /// 모든 아이템을 제거하고 내부 배열을 초기화합니다. <br/>
    /// Clear()와 달리 메모리 누수 위험이 없습니다. 값 형식이거나 메모리 누수 위험이 없다면 Clear()를 사용하는 것이 성능상 좋습니다.
    /// </summary>
    public void ClearCompletely()
    {
        for (int i = 0; i < Count; i++)
        {
            memory.Span[i] = default;
        }
        memoryGetter.Return(memory);
        memory = memoryGetter.Get(0);
    }

    public ReadOnlyMemoryEnumerator<KeyValuePair> GetEnumerator()
        => new ReadOnlyMemoryEnumerator<KeyValuePair>(memory);



    void Insert(int index, TKey key, TValue value)
    {
        GetMemory(Count + 1);
        Seperate(index);
        memory.Span[index] = new KeyValuePair(key, value);
    }
    /// <summary>
    /// 지정된 인덱스의 아이템부터 뒤로 밀어냅니다. <br/>
    /// index의 아이템은 다음 인덱스로 복제됩니다.
    /// </summary>
    /// <param name="index"></param>
    /// <param name="count"></param>
    void Seperate(int index, int count = 1)
    {
        if (index >= this.Count)
        {
            GetMemory(this.Count + count);
        }
    }

    void GetMemory(int length)
    {
        Span<KeyValuePair> span = memory.Span;
        memory = memoryGetter.Get(length);
        span.CopyTo(memory.Span);
        memoryGetter.Return(memory);
    }

    /// <summary>
    /// index 다음 아이템부터 index로 당겨옵니다. <br/>
    /// 참조가 제거되지 않으므로 메모리 누수 위험이 있습니다. 마지막 원소를 초기화하려면 CompletelyPull()를 사용하세요.
    /// </summary>
    /// <param name="index"></param>
    void Pull(int index)
    {
        CheckListEmpty();

        memory[(index + 1)..(Count - 1)].CopyTo(memory.Slice(index));
    }
    /// <summary>
    /// index 다음 아이템부터 index로 당겨옵니다. <br/>
    /// Pull()와 달리 메모리 누수 위험이 없습니다. 값 형식이거나 메모리 누수 위험이 없다면 Pull()를 사용하는 것이 성능상 좋습니다.
    /// </summary>
    /// <param name="index"></param>
    void PullCompletely(int index)
    {
        memory[(index + 1)..(Count - 1)].CopyTo(memory.Slice(index));
    }

    int GetHasSameOrLessKeyPairIndex(TKey key, out bool isSame)
    {
        switch (memory.Length)
        {
            case 0:
            {
                isSame = false;
                return -1;
            }
            case 1:
            {
                ref KeyValuePair item = ref memory.Span[0];
                int compare = item.key.CompareTo(key);

                if (compare == 0)
                {
                    isSame = true;
                    return 0;
                }
                else if (compare < 0)
                {
                    isSame = false;
                    return 0;
                }
                else
                {
                    isSame = false;
                    return -1;
                }
            }
            default:
            {
                Span<KeyValuePair> span = memory.Span;

                // 첫 아이템 비교
                ref KeyValuePair firstItem = ref span[0];
                int firstItemCompare = firstItem.key.CompareTo(key);
                if (firstItemCompare == 0)
                {
                    isSame = true;
                    return 0;
                }
                // key < first
                else if (0 < firstItemCompare)
                {
                    isSame = false;
                    return -1;
                }

                // 마지막 아이템 비교
                int lastItemIndex = Count - 1;
                ref KeyValuePair lastItem = ref span[lastItemIndex];
                int lastItemCompare = lastItem.key.CompareTo(key);
                if (lastItemCompare == 0)
                {
                    isSame = true;
                    return lastItemIndex;
                }
                // last < key
                else if (lastItemCompare < 0)
                {
                    isSame = false;
                    return lastItemIndex;
                }

                // 두 개만 있었으면
                if (Count == 2)
                {
                    isSame = false;
                    return 0;
                }

                // 두 개 이상
                int min = 1;
                int max = span.Length - 2;

                while (true)
                {
                    int mid = (min + max) >> 1;
                    KeyValuePair midPair = span[mid];
                    TKey midKey = midPair.key;

                    int midKeyCompare = midKey.CompareTo(key);
                    if (midKeyCompare == 0)
                    {
                        isSame = true;
                        return mid;
                    }

                    if (midKeyCompare < 0)
                    {
                        if (mid == min)
                        {
                            isSame = false;
                            return mid;
                        }
                        min = mid + 1;
                    }
                    else
                    {
                        max = mid - 1;
                    }
                }
            }
        }
    }
}
