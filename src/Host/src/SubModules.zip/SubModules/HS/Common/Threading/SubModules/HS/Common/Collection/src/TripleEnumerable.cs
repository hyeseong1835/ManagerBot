using System.Collections;
using System.Collections.Generic;

namespace HS.Common.Collection;

public struct TripleEnumerable<T> : IEnumerable<T>
{
    public T value1;
    public T value2;
    public T value3;

    public TripleEnumerable(T value1, T value2, T value3)
    {
        this.value1 = value1;
        this.value2 = value2;
        this.value3 = value3;
    }
    public IEnumerator<T> GetEnumerator()
    {
        yield return value1;
        yield return value2;
        yield return value3;
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }
}
