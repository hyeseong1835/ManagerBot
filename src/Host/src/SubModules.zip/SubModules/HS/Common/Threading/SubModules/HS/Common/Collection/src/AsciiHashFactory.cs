using System;
using System.Numerics;

namespace HS.Common.Collection
{
    public readonly struct AsciiHashFactory
    {
        struct AsciiCompareInfo
        {
            public readonly int index;
            public readonly char minChar;
            public readonly int x;

            public AsciiCompareInfo(int index, char minChar, int x)
            {
                this.index = index;
                this.minChar = minChar;
                this.x = x;
            }
        }
        struct IndexInfo
        {
            public static IndexInfo GetIndexInfo(int index, Span<ulong> cleanBuffer, ReadOnlySpan<byte> asciiBytesChain, ReadOnlySpan<int> elementLengths)
            {
                if (elementLengths.Length == 0)
                    return new IndexInfo(index, 0, 0, 0);

                byte b;
                if (elementLengths.Length == 1)
                {
                    b = asciiBytesChain[index];
                    return new IndexInfo(index, b, 1, 1);
                }

                byte minChar = byte.MaxValue;
                byte maxChar = byte.MinValue;

                int byteI = index;
                int elementLength;
                int bDivide32;

                for (int element = 0; element < elementLengths.Length; element++)
                {
                    elementLength = elementLengths[element];

                    b = asciiBytesChain[byteI];
                    bDivide32 = (b << -5);

                    cleanBuffer[bDivide32] |= (byte)(1 << (b - (bDivide32 << 5)));

                    if (b < minChar)
                        minChar = b;

                    if (b > maxChar)
                        maxChar = b;

                    byteI += elementLength;
                }

                byte charRangeLength = (byte)(maxChar - minChar + 1);

                byte kindCount = (byte)(BitOperations.PopCount(cleanBuffer[0])
                                        + BitOperations.PopCount(cleanBuffer[1])
                                        + BitOperations.PopCount(cleanBuffer[2])
                                        + BitOperations.PopCount(cleanBuffer[3]));

                return new IndexInfo(index, minChar, charRangeLength, kindCount);
            }

            public static IndexInfo[] GetIndexInfos(ReadOnlySpan<byte> asciiBytesChain, ReadOnlySpan<int> elementLengths)
            {
                int elementCount = elementLengths.Length;
                IndexInfo[] indexInfos = new IndexInfo[elementCount];

                Span<ulong> buffer = stackalloc ulong[4];
                int i;
                for (i = 0; i < elementCount - 1; i++)
                {
                    indexInfos[i] = IndexInfo.GetIndexInfo(i, buffer, asciiBytesChain, elementLengths);
                    buffer[0] = 0;
                    buffer[1] = 0;
                    buffer[2] = 0;
                    buffer[3] = 0;
                }
                indexInfos[i] = IndexInfo.GetIndexInfo(i, buffer, asciiBytesChain, elementLengths);

                return indexInfos;
            }

            public int index;
            public byte minChar;
            public byte charRangeLength;
            public byte charKindCount;

            IndexInfo(int index, byte minChar, byte charRangeLength, byte charKindCount)
            {
                this.index = index;
                this.minChar = minChar;
                this.charRangeLength = charRangeLength;
                this.charKindCount = charKindCount;
            }
        }
        struct Group
        {
            public readonly byte b;
            public Memory<int> indexInfoIndexes;

            public Group(byte b, Memory<int> indexInfoIndexes)
            {
                this.b = b;
                this.indexInfoIndexes = indexInfoIndexes;
            }
        }
/*
        public static AsciiHashFactory CreateOptimalFactory(ReadOnlySpan<byte> asciiBytesChain, ReadOnlySpan<int> elementLengths,
            int maxElementLength)
        {
            int elementCount = elementLengths.Length;

            if (elementCount <= 1)
                return new AsciiHashFactory();

            IndexInfo[] indexInfos = IndexInfo.GetIndexInfos(asciiBytesChain, elementLengths);
            int indexInfoLength = indexInfos.Length;
            Array.Sort(indexInfos, static (a, b) => a.charKindCount - b.charKindCount);

            Group[] rootGroupBuffer = new Group[indexInfos[0].charKindCount];

            for (int indexInfoI = 0; indexInfoI < indexInfoLength; indexInfoI++)
            {
                IndexInfo indexInfo = indexInfos[indexInfoI];


            }

            int elementStartIndex = 0;
            for (int element = 0; element < elementLengths.Length; element++)
            {
                int elementLength = elementLengths[element];

                elementStartIndex += elementLength;
            }
        }
*/
        readonly bool compress;
        readonly int minLength;
        readonly AsciiCompareInfo[] compares;

        public AsciiHashFactory()
        {
            compares = Array.Empty<AsciiCompareInfo>();
        }
        AsciiHashFactory(AsciiCompareInfo[] compares)
        {
            this.compares = compares;
        }

        public ulong GetHash(string str)
        {
            int findIndexCount = compares.Length;
            if (findIndexCount == 0)
                return 0; // 값이 1개이므로 구분될 필요 없음

            ulong hash;

            int strLength = str.Length;
            if (strLength == 0)
                return 0; // 길이가 0이므로 계산할 필요 없음

            // 압축함
            if (compress)
            {
                AsciiCompareInfo compare = compares[0];

                // 탐색할 범위가 1개인 경우 최적화
                if (findIndexCount == 1)
                {
                    if (compare.index >= strLength)
                        return 0;

                    hash = (ulong)((str[compare.index] - compare.minChar) * compare.x);
                    return hash;
                }


                hash = (ulong)(str[compare.index] - compare.minChar);
                int times = compare.x;

                // 중간 반복
                int indexRepeatCount = findIndexCount - 1;
                int compareI;
                for (compareI = 1; compareI < indexRepeatCount; compareI++)
                {
                    compare = compares[compareI];
                    if (compare.index < strLength)
                        hash += (ulong)((str[compare.index] - compare.minChar) * times);

                    times *= compare.x;
                }

                // 마지막은 곱셈 생략
                compare = compares[compareI];
                if (compare.index < strLength)
                    hash += (ulong)((str[compare.index] - compare.minChar) * times);
            }
            else
            {
                AsciiCompareInfo compare = compares[0];

                // 탐색할 범위가 1개인 경우 최적화
                if (findIndexCount == 1)
                {
                    if (compare.index >= strLength)
                        return 0;

                    hash = (ulong)((str[compare.index] - compare.minChar) << compare.x);
                    return hash;
                }


                hash = (ulong)(str[compare.index] - compare.minChar);
                int times = compare.x;

                // 중간 반복
                int indexRepeatCount = findIndexCount - 1;
                int compareI;
                for (compareI = 1; compareI < indexRepeatCount; compareI++)
                {
                    compare = compares[compareI];
                    if (compare.index < strLength)
                        hash += (ulong)((str[compare.index] - compare.minChar) << times);

                    times *= compare.x;
                }

                // 마지막은 곱셈 생략
                compare = compares[compareI];
                if (compare.index < strLength)
                    hash += (ulong)((str[compare.index] - compare.minChar) << times);
            }

            return hash;
        }
    }
}
