using System;

namespace HS.Common.Collection;

public ref struct ReadOnlySpanEnumerator<T>
{
    readonly ReadOnlySpan<T> span;
    int index;

    public T Current => span[index];

    public ReadOnlySpanEnumerator(ReadOnlySpan<T> span, int startIndex = -1)
    {
        this.span = span;
        this.index = startIndex;
    }


    public bool MoveNext()
    {
        if (index + 1 >= span.Length)
            return false;

        index++;
        return true;
    }

    public void Reset()
    {
        index = -1;
    }
}
