using System;
using System.Collections;
using System.Collections.Generic;

namespace HS.Common.Collection.Unmanaged;

unsafe public struct UnmanagedValueLinkedListValueEnumerator<TValue>
    : IEnumerator<TValue>
    where TValue : unmanaged
{
    #region Static

    // UnmanagedValueLinkedListValueEnumerator<TValue, UnmanagedLinkedListNode<TValue>, UnmanagedLinkedListNodeEnumerator<TValue>> => this
    public static implicit operator UnmanagedValueLinkedListValueEnumerator<TValue>(UnmanagedValueLinkedListValueEnumerator<TValue, UnmanagedValueLinkedListNode<TValue>> enumerator)
        => new UnmanagedValueLinkedListValueEnumerator<TValue>(enumerator);

    public static implicit operator UnmanagedValueLinkedListValueEnumerator<TValue, UnmanagedValueLinkedListNode<TValue>>(UnmanagedValueLinkedListValueEnumerator<TValue> enumerator)
        => new UnmanagedValueLinkedListValueEnumerator<TValue, UnmanagedValueLinkedListNode<TValue>>(enumerator);

    #endregion


    #region Instance

    #region Field & Property

    UnmanagedLinkedListNodeEnumerator<UnmanagedValueLinkedListNode<TValue>> nodeEnumerator;
    public bool IsEnd => nodeEnumerator.IsEnd;

    public TValue CurrentValue => nodeEnumerator.CurrentNodePtr->Value;
    object IEnumerator.Current => CurrentValue;
    TValue IEnumerator<TValue>.Current => CurrentValue;

    #endregion


    #region Constructor

    public UnmanagedValueLinkedListValueEnumerator(UnmanagedLinkedList<UnmanagedValueLinkedListNode<TValue>> rawlist)
        : this(rawlist.HeadNodePtr) { }
    public UnmanagedValueLinkedListValueEnumerator(UnmanagedValueLinkedListNode<TValue>* listHeadNodePtr)
        : this(new UnmanagedLinkedListNodeEnumerator<UnmanagedValueLinkedListNode<TValue>>(listHeadNodePtr)) { }
    public UnmanagedValueLinkedListValueEnumerator(UnmanagedValueLinkedList<TValue> list)
        : this(list.GetNodeEnumerator()) { }
    public UnmanagedValueLinkedListValueEnumerator(UnmanagedValueLinkedListValueEnumerator<TValue> enumerator)
        : this(enumerator.nodeEnumerator) { }
    public UnmanagedValueLinkedListValueEnumerator(UnmanagedLinkedListNodeEnumerator<UnmanagedValueLinkedListNode<TValue>> nodeEnumerator)
    {
        this.nodeEnumerator = nodeEnumerator;
    }

    #endregion


    #region Method

    void IDisposable.Dispose() => throw new NotImplementedException();

    public bool MoveNext()
        => nodeEnumerator.MoveNext();

    public void Reset()
        => nodeEnumerator.Reset();

    public UnmanagedValueLinkedListValueEnumerator<TValue> Copy()
        => new UnmanagedValueLinkedListValueEnumerator<TValue>(this);

    #endregion

    #endregion
}

unsafe public struct UnmanagedValueLinkedListValueEnumerator<TValue, TNode>
    : IEnumerator<TValue>
    where TValue : unmanaged
    where TNode : unmanaged, IUnmanagedValueLinkedListNode<TValue, TNode>
{
    #region Field & Property

    object IEnumerator.Current => nodeEnumerator.CurrentNodePtr->Value;
    TValue IEnumerator<TValue>.Current => nodeEnumerator.CurrentNodePtr->Value;

    UnmanagedLinkedListNodeEnumerator<TNode> nodeEnumerator;

    public bool IsEnd => nodeEnumerator.IsEnd;

    #endregion


    #region Constructor

    public UnmanagedValueLinkedListValueEnumerator(UnmanagedLinkedList<TNode> rawlist)
        : this(rawlist.HeadNodePtr) { }
    public UnmanagedValueLinkedListValueEnumerator(TNode* listHeadNodePtr)
        : this(new UnmanagedLinkedListNodeEnumerator<TNode>(listHeadNodePtr)) { }

    public UnmanagedValueLinkedListValueEnumerator(UnmanagedValueLinkedListValueEnumerator<TValue, TNode> enumerator)
        : this(enumerator.nodeEnumerator) { }
    public UnmanagedValueLinkedListValueEnumerator(UnmanagedLinkedListNodeEnumerator<TNode> nodeEnumerator)
    {
        this.nodeEnumerator = nodeEnumerator;
    }
    public UnmanagedValueLinkedListValueEnumerator(UnmanagedValueLinkedList<TValue, TNode> list)
        : this(list.GetNodeEnumerator()) { }

    #endregion


    #region Method

    void IDisposable.Dispose() => throw new NotImplementedException();

    public bool MoveNext()
        => nodeEnumerator.MoveNext();

    public void Reset()
        => nodeEnumerator.Reset();

    public UnmanagedValueLinkedListValueEnumerator<TValue, TNode> Copy()
        => new UnmanagedValueLinkedListValueEnumerator<TValue, TNode>(this);

    #endregion
}
