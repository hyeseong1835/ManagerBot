using System;
using System.Diagnostics.CodeAnalysis;

namespace HS.Common.Collection
{
    public class ArrayQueue<T> : IQueue<T>
    {
        const int DefaultCapacity = 16;

        T?[] _array;
        int _head;
        int _tail;

        int _count;
        public int Count => _count;

        public ArrayQueue(int capacity = DefaultCapacity)
        {
            _array = new T?[capacity];
            _head = 0;
            _tail = 0;

            _count = 0;
        }

        public void Enqueue(T item)
        {
            if (item == null)
                throw new ArgumentNullException(nameof(item));

            if (_count == _array.Length)
            {
                int newCapacity = _array.Length * 2;
                T?[] newArray = new T?[newCapacity];

                Buffer.BlockCopy(
                    _array, _head,
                    newArray, 0,
                    _count
                );

                _array = newArray;
                _head = 0;
                _tail = _count;
            }

            _array[_tail++] = item;
            if (_tail == _array.Length)
            {
                _tail = 0;
            }

            _count++;
        }

        public bool TryDequeue([NotNullWhen(true)] out T? item)
        {
            if (_count == 0)
            {
                item = default;
                return false;
            }

            ref T? itemRef = ref _array[_head];

            item = itemRef!;
            itemRef = default;

            _head++;
            if (_head == _array.Length)
            {
                _head = 0;
            }

            _count--;
            return true;
        }
    }

}
