using System.Collections;
using System.Collections.Generic;

namespace HS.Common.Collection;

public struct DoubleEnumerable<T> : IEnumerable<T>
{
    public T value1;
    public T value2;

    public DoubleEnumerable(T value1, T value2)
    {
        this.value1 = value1;
        this.value2 = value2;
    }
    public IEnumerator<T> GetEnumerator()
    {
        yield return value1;
        yield return value2;
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }
}
